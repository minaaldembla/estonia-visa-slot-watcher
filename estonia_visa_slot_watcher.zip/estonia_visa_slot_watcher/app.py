import os
import re
import json
import hashlib
import logging
import smtplib
from email.message import EmailMessage
from datetime import datetime, timezone
from pathlib import Path

from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeoutError
from twilio.rest import Client

logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"), format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("estonia-slot-watcher")

BOOKING_URL = os.getenv("BOOKING_URL", "https://broneering.mfa.ee/en/")
EMBASSY_TEXT = os.getenv("EMBASSY_TEXT", "New Delhi")
SERVICE_TEXT = os.getenv("SERVICE_TEXT", "Long-stay visa (D-visa) application")
STATE_FILE = Path(os.getenv("STATE_FILE", "last_state.json"))
ALERT_ON_FIRST_RUN = os.getenv("ALERT_ON_FIRST_RUN", "false").lower() == "true"
HEADLESS = os.getenv("HEADLESS", "true").lower() == "true"

def send_email(subject: str, body: str) -> None:
    host = os.getenv("SMTP_HOST")
    port = int(os.getenv("SMTP_PORT", "587"))
    user = os.getenv("SMTP_USER")
    password = os.getenv("SMTP_PASSWORD")
    recipient = os.getenv("ALERT_EMAIL_TO")
    sender = os.getenv("ALERT_EMAIL_FROM", user or "")
    if not all([host, user, password, recipient, sender]):
        log.warning("Email not configured; skipping email alert.")
        return
    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = sender
    msg["To"] = recipient
    msg.set_content(body)
    with smtplib.SMTP(host, port, timeout=20) as server:
        server.starttls()
        server.login(user, password)
        server.send_message(msg)
    log.info("Email alert sent.")

def send_whatsapp(body: str) -> None:
    sid = os.getenv("TWILIO_ACCOUNT_SID")
    token = os.getenv("TWILIO_AUTH_TOKEN")
    sender = os.getenv("TWILIO_WHATSAPP_FROM")  # e.g. whatsapp:+14155238886 for sandbox
    recipient = os.getenv("TWILIO_WHATSAPP_TO") # e.g. whatsapp:+91XXXXXXXXXX
    if not all([sid, token, sender, recipient]):
        log.warning("WhatsApp not configured; skipping WhatsApp alert.")
        return
    Client(sid, token).messages.create(body=body[:1500], from_=sender, to=recipient)
    log.info("WhatsApp alert sent.")

def alert_once(title: str, body: str) -> None:
    errors = []
    for name, fn in (("email", lambda: send_email(title, body)), ("WhatsApp", lambda: send_whatsapp(body))):
        try:
            fn()
        except Exception as exc:
            errors.append(f"{name}: {exc}")
            log.exception("%s alert failed", name)
    if errors:
        log.warning("One or more alert channels failed: %s", "; ".join(errors))

def read_state():
    try:
        return json.loads(STATE_FILE.read_text())
    except Exception:
        return {}

def write_state(state):
    try:
        STATE_FILE.write_text(json.dumps(state, indent=2))
    except Exception:
        log.warning("Could not persist state file; on ephemeral hosts, use persistent storage or an external state store.")

def inspect_calendar():
    """Navigate the public booking flow and check whether the D-visa service appears.
    This does not book an appointment, bypass CAPTCHAs, or submit personal details.
    """
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=HEADLESS)
        page = browser.new_page(locale="en-GB")
        page.set_default_timeout(12000)
        page.goto(BOOKING_URL, wait_until="domcontentloaded", timeout=30000)
        page.wait_for_timeout(1500)

        # The first page asks for a representation/embassy and number of persons.
        selected_embassy = False
        selects = page.locator("select")
        for i in range(selects.count()):
            sel = selects.nth(i)
            try:
                options = sel.locator("option").all_text_contents()
                matching = next((o.strip() for o in options if EMBASSY_TEXT.lower() in o.lower()), None)
                if matching:
                    sel.select_option(label=matching)
                    selected_embassy = True
                    log.info("Selected representation option: %s", matching)
                    break
            except Exception:
                continue

        # If no native select was detected, do not guess/click arbitrary UI controls.
        if not selected_embassy:
            body = page.locator("body").inner_text(timeout=5000)
            browser.close()
            raise RuntimeError(
                "Could not identify a native embassy dropdown containing '"
                + EMBASSY_TEXT
                + "'. The booking site may have changed or use a custom selector. "
                + "First-page text excerpt: " + body[:500].replace("\\n", " ")
            )

        # Set applicant count to one if the page exposes a numeric input.
        inputs = page.locator("input")
        for i in range(inputs.count()):
            item = inputs.nth(i)
            try:
                typ = (item.get_attribute("type") or "").lower()
                if typ in ("number", "text") and item.is_visible():
                    current = item.input_value()
                    if current.isdigit() or not current:
                        item.fill("1")
                        break
            except Exception:
                continue

        # Advance only to the service-selection screen; never submit a booking.
        next_patterns = re.compile(r"(to the next page|next|continue|edasi)", re.I)
        clicked = False
        for locator in [
            page.get_by_role("button", name=next_patterns),
            page.locator('input[type="submit"]'),
            page.locator('button[type="submit"]'),
        ]:
            try:
                if locator.count() and locator.first.is_visible():
                    locator.first.click()
                    clicked = True
                    break
            except Exception:
                pass

        if clicked:
            try:
                page.wait_for_load_state("domcontentloaded", timeout=10000)
            except PlaywrightTimeoutError:
                pass
            page.wait_for_timeout(2000)

        body_text = page.locator("body").inner_text(timeout=5000)
        service_visible = SERVICE_TEXT.casefold() in body_text.casefold()
        url = page.url
        # Save a compact diagnostic excerpt without storing cookies or user data.
        excerpt = body_text[:1200]
        browser.close()
        return {
            "service_visible": service_visible,
            "url": url,
            "excerpt": excerpt,
            "checked_at": datetime.now(timezone.utc).isoformat(),
        }

def main():
    result = inspect_calendar()
    log.info("Check complete: service_visible=%s url=%s", result["service_visible"], result["url"])
    state = read_state()
    current = "visible" if result["service_visible"] else "not_visible"
    previous = state.get("status")

    if result["service_visible"] and (previous != "visible" or ALERT_ON_FIRST_RUN):
        message = (
            "POSSIBLE ESTONIAN D-VISA APPOINTMENT OPENING\n\n"
            f"The service '{SERVICE_TEXT}' appears on the Estonia booking flow for the representation matching '{EMBASSY_TEXT}'.\n\n"
            "This is an early signal, not a guarantee that a bookable time remains. Open the official site and check immediately:\n"
            f"{BOOKING_URL}\n\n"
            f"Checked at (UTC): {result['checked_at']}\n"
            "The watcher has not booked anything."
        )
        alert_once("Estonia D-visa service detected", message)
    elif not result["service_visible"] and previous == "visible":
        log.info("Service no longer visible; watcher reset for the next appearance.")

    # Save state only after a successful inspection.
    write_state({"status": current, "checked_at": result["checked_at"], "url": result["url"]})

if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        log.exception("Monitor check failed")
        # Failures are logged, not treated as availability.
        # Optional diagnostic alerts can be enabled without repeatedly spamming.
        if os.getenv("ALERT_ON_ERRORS", "false").lower() == "true":
            alert_once("Estonia slot watcher needs attention", f"The watcher could not complete a check.\n\nError: {exc}\n\nBooking site: {BOOKING_URL}")
        raise
