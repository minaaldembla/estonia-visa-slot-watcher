# Estonia D-visa appointment watcher

A small Playwright-based monitor for the Estonia consular booking site. It selects the representation matching `New Delhi`, advances to the service-selection screen, and alerts if the exact service text `Long-stay visa (D-visa) application` appears.

**It only detects and alerts. It does not book appointments, submit personal details, bypass CAPTCHAs, or evade access controls.** A service appearing is a potential opening, not proof that a slot remains bookable.

## Important limitations

- The booking site's interface may change or use custom controls. The script currently expects a native HTML `<select>` for the representation and a visible next-page button. If it cannot find those, it stops and logs a diagnostic rather than guessing.
- The GitHub Actions workflow is a starter deployment. Scheduled jobs are best-effort, can be delayed, and GitHub's cache is not a durable state database. If you need reliable continuous monitoring, use a small always-on/cron host with persistent state.
- Do not run checks aggressively. The default GitHub schedule is every 10 minutes. Respect the website's terms and any rate limits.
- WhatsApp requires an authorized sender. Twilio's WhatsApp Sandbox is for testing and is not suitable as a permanent production alert channel. For production, set up a WhatsApp Business Platform sender with Twilio (or another official provider); business-initiated messages may require approved templates and fees.

## 1. Configure email

For Gmail:
1. Turn on 2-Step Verification on the Google account.
2. Create an App Password in Google Account security settings (if your account supports it).
3. Use the App Password as `SMTP_PASSWORD`; never use your normal Google password.

Other SMTP providers can be used by changing `SMTP_HOST`, `SMTP_PORT`, and credentials.

## 2. Configure WhatsApp

For testing:
1. Create a Twilio account and open its WhatsApp testing / Sandbox setup.
2. Follow Twilio's steps to join the Sandbox from the WhatsApp number that should receive alerts.
3. Copy the account SID, auth token, Sandbox sender, and recipient into environment variables.
4. Sandbox membership can expire and the Sandbox is for testing, not permanent production use.

For production, configure a WhatsApp-enabled sender through the official WhatsApp Business Platform provider. Set `TWILIO_WHATSAPP_FROM` to your approved sender in `whatsapp:+<countrycode><number>` form. Check current provider pricing and message/template rules.

## 3. Test locally first

Python 3.12 recommended.

```bash
python -m venv .venv
# macOS/Linux:
source .venv/bin/activate
# Windows PowerShell:
# .venv\Scripts\Activate.ps1

pip install -r requirements.txt
playwright install chromium
cp .env.example .env
```

Fill in `.env`, then load the variables into your shell. Easiest cross-platform option is to use a `.env` loader (install `python-dotenv` and add `load_dotenv()` at the top of `app.py`), or set the environment variables manually. Do not commit `.env`.

Run:
```bash
python app.py
```

If it fails to identify the embassy dropdown, the site likely changed or uses a custom control. Open the booking site in a normal browser, inspect the page structure, and update the selectors in `inspect_calendar()`; do not add logic to bypass any CAPTCHA or access controls.

## 4. GitHub Actions starter deployment

1. Create a **private** GitHub repository and upload the contents of this folder.
2. In the repo, go to **Settings → Secrets and variables → Actions**.
3. Add these **Secrets**:
   - `SMTP_HOST` = `smtp.gmail.com`
   - `SMTP_PORT` = `587`
   - `SMTP_USER` = sender Gmail address
   - `SMTP_PASSWORD` = Gmail App Password
   - `ALERT_EMAIL_FROM` = sender address
   - `ALERT_EMAIL_TO` = recipient address
   - `TWILIO_ACCOUNT_SID`
   - `TWILIO_AUTH_TOKEN`
   - `TWILIO_WHATSAPP_FROM`
   - `TWILIO_WHATSAPP_TO`
4. Under **Variables**, add:
   - `BOOKING_URL` = `https://broneering.mfa.ee/en/`
   - `EMBASSY_TEXT` = `New Delhi`
   - `SERVICE_TEXT` = `Long-stay visa (D-visa) application`
5. Go to **Actions**, enable workflows, select **Check Estonia D-visa service**, then click **Run workflow** for the first test.
6. Read the run logs. Confirm the script successfully selected New Delhi and reached the service page. Do not rely on alerts until a successful end-to-end test has completed.
7. GitHub's scheduled workflow is not guaranteed to run exactly on schedule. Scheduled workflows can be delayed or disabled in inactive repositories. For more reliable checks, deploy the container to a host with scheduled jobs and persistent storage.

## 5. State and duplicate alerts

The script alerts on the transition from service absent to service present. `last_state.json` remembers the previous state. On ephemeral or cache-based hosts, state may be lost and duplicate alerts can happen. For a production deployment, persist this file or replace it with a tiny SQLite/database record.

## 6. Safe operating settings

- Start with 10-minute checks.
- Do not run parallel copies.
- Do not attempt to book automatically.
- If the website presents CAPTCHA, login, or access restrictions, stop and complete those steps manually.
- Treat an alert as a prompt to open the official page immediately, not as a confirmed reservation.
